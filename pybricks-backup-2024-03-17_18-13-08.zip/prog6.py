def prog6(hub:PrimeHub, robot:DriveBase, bg:Motor, bd:Motor):
 # 2024-03-16
 
 # Je place le robot
 # Todo

 # Il va a la mission 8
 robot.turn(0)
 # Todo

 # Il fait la mission 8
 # Todo
 
 # Il rentre a la base
 # Todo