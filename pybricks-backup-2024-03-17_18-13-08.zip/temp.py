
#def prog5(robot, bg, bd):
 # 2024-03-16
 
 # Je place le robot, avec le module
 # Todo

 # Le robot va a la mission 6
 # Todo
 
 # Je fais la mission 6
 # Todo
 
 # Je fais la mission 7
 # Todo

 # Je reviens a la base
 # Todo


def prog6(robot, bg, bd):
 # 2024-03-16
 
 # Je place le robot
 # Todo

 # Il va a la mission 8
 # Todo

 # Il fait la mission 8
 # Todo
 
 # Il rentre a la base
 # Todo

def prog6(robot, bg, bd):
 # 2024-03-16
 
 # Je place le robot
 # Todo

 # Il va a la mission 8
 # Todo

 # Il fait la mission 8
 # Todo
 
 # Il rentre a la base
 # Todo

def prog7(robot, bg, bd):
 # 2024-03-16
 
 # Je place le robot
 # Todo

 # Le robot va aux missions 12 et 13
 # Todo

 # Il fait la mission 12
 # Todo

 # Il fait la mission 13
 # Todo

 # Il termine la mission 12
 # Todo

 # Il rentre à la base
 # Todo

