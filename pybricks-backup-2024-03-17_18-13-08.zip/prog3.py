def prog3(hub:PrimeHub, robot:DriveBase, bg:Motor, bd:Motor):
 # 2024-03-16
 # 1 - Le code pour le cinema 3D

 #J'y vais
 robot.straight(250)
 
 #Je réalise la mission
 #Todo