def prog7(hub:PrimeHub, robot:DriveBase, bg:Motor, bd:Motor):
 # 2024-03-16
 
 # Je place le robot
 # Todo

 # Le robot va aux missions 12 et 13
 robot.turn(0)
 # Todo

 # Il fait la mission 12
 # Todo

 # Il fait la mission 13
 # Todo

 # Il termine la mission 12
 # Todo

 # Il rentre à la base
 # Todo