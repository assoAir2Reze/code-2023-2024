def prog5(hub:PrimeHub, robot:DriveBase, bg:Motor, bd:Motor):

# 2024-03-16
 
 # Je place le robot, avec le module
 # Todo

 # Le robot va a la mission 6
  robot.turn(0)
 # Todo
 
 # Je fais la mission 6
 # Todo
 
 # Je fais la mission 7
 # Todo

 # Je reviens a la base
 # Todo